
public class Link {
	public Link left;
	public Link right;
	public Link parent;
	int data;
	int priority;
	public Link(int val,int priority){
		left= null;
		right= null;
		parent= null;
		data= val;
		this.priority= priority;
	}
	public void display(int val){
		System.out.println(val);
	}
}
