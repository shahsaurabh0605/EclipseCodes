import java.util.*;
public class Main {
	public static void main(String args[]){
		Scanner s= new Scanner(System.in);
		BST node= new BST();
		int n= s.nextInt();
		int arr1[]= new int[n+1];
		int arr2[]= new int[n+1];
		for(int i=1;i<=n;i++){
			arr1[i]= s.nextInt();
			arr2[i]= s.nextInt();
			if(i==1)
				node.insert(arr1[i],arr2[i]);
			else{
				node.insert(arr1[i],arr2[i]);
				while(node.current.parent!=null && node.current.priority<node.current.parent.priority){
					//System.out.println("current= "+node.current.data+"parent= "+node.current.parent.data);
					if(node.current.data<node.current.parent.data){
						//System.out.println("sr "+i);
						node.rotateRight(node.current.parent);
						//System.out.println(node.head.data);
					}
					else{
						//System.out.println(" sa"+i);
						node.rotateLeft(node.current.parent);
						//System.out.println(node.head.data);
					}
				}
			}
		}
		node.print(node.head);
	}
}
