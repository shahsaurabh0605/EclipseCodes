import java.util.*;
public class Main {
	public static void main(String args[]){
		Scanner s= new Scanner(System.in);
		int n= s.nextInt();
		int arr1[]= new int[n+1];
		int heap[]= new int[n+1];
		for(int i=1;i<=n;i++){
			arr1[i]= s.nextInt();
			if(i==1);
			else{
				if(level(i/2)%2==0){
					if(arr1[i]<arr1[i/2]){
						int t= arr1[i];
						arr1[i]= arr1[i/2];
						arr1[i/2]=t;
						//System.out.println(arr1[i/2]);
						verify_min(arr1,i/2);
					}
					else{
						verify_max(arr1,i);
					}
				}
				else{
					if(arr1[i]>arr1[i/2]){
						int t= arr1[i];
						arr1[i]= arr1[i/2];
						arr1[i/2]=t;
						verify_max(arr1,i/2);
					}
					else {
						verify_min(arr1,i);
					}
				}
			}
		}
		for(int i=1;i<=n;i++){
			System.out.print(arr1[i]+" ");
		}
	}
	public static void verify_max(int arr1[],int i){
		int grandparent= i/4;
		while(grandparent!=0){
			//System.out.println("dd");
			if(arr1[i]> arr1[grandparent]){
				int t= arr1[i];
				arr1[i]= arr1[grandparent];
				arr1[grandparent]=t;
				grandparent= grandparent/4;
			}
			else{
				break;
			}
		}
	}
	public static void verify_min(int arr1[],int i){
		int grandparent= i/4;
		while(grandparent!=0){
			//System.out.println("ss");
			if(arr1[i]< arr1[grandparent]){
				int t= arr1[i];
				arr1[i]= arr1[grandparent];
				arr1[grandparent]=t;
				//System.out.println(i);
				grandparent= grandparent/4;
			}
			else{
				break;
			}
		}
	}
	public static int level(int n){
		int level1= (int) (Math.log(n)/Math.log(2));
		return level1;
	}
}
